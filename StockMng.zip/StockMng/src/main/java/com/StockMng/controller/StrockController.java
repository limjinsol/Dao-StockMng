package com.StockMng.controller;

import com.StockMng.dto.StockDTO;
import com.StockMng.service.StockService;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

@Controller
public class StrockController {
    @Autowired
    StockService stockService;
    @GetMapping("/")
    public String index() {
        return "index"; //화면 매핑
    }
    @RequestMapping("/list")
    public String stockList(Model model){

        model.addAttribute("list2",stockService.selectList());
        System.out.println("model = " + model);
        return "list";
    }

    @PostMapping("/productIdChk")
    public @ResponseBody String productIdChk(HttpServletRequest request){
        String productCode = request.getParameter("productCode");
        System.out.println("----------------------------------------------");
        System.out.println("productCode = " + productCode);
        int cnt = stockService.selectShippingProductIdCnt(productCode);
        String checkResult = "";
        if(cnt < 1){
            checkResult = "no";
        }else{
            checkResult = stockService.selectShippingProductId(productCode);
        }
        System.out.println("----------------------------------------------");
        System.out.println("checkResult = " + checkResult);
        return checkResult;
    }

    @PostMapping("/locationIdchk")
    public @ResponseBody String locationIdchk(HttpServletRequest request){
        String locationName = request.getParameter("locationName");
        System.out.println("----------------------------------------------");
        System.out.println("locationName = " + locationName);
        int cnt = stockService.selectLocationIdchk(locationName);
        String checkResult = "";
        if(cnt < 1){
            checkResult = "no";
        }else{
            checkResult = stockService.selectlocationId(locationName);
        }
        System.out.println("----------------------------------------------");
        System.out.println("checkResult = " + checkResult);
        return checkResult;
    }

    @PostMapping("/suggestionlocationCode")
    public @ResponseBody String suggestionlocationCode(HttpServletRequest request){
        String productId = request.getParameter("productId");

        if(productId.equals("없는 상품코드")){
            return "no";
        }
        return stockService.selectsuggestionlocationCode(productId);
    }

    @RequestMapping("/save")
    public String save(HttpServletRequest request, Model model) throws IOException {
        int result = 0;
        String errMsg = "";
        try {
            String shipping_product_id = request.getParameter("result_product_id");
            String quantity = request.getParameter("quantity");
            String location_id = request.getParameter("result_location_id");


            if (shipping_product_id.isEmpty() || quantity.isEmpty() || location_id.isEmpty()) {
                model.addAttribute("message", "빈값이 존재하여 저장처리할 수 없습니다!!");
                model.addAttribute("searchUrl", "/");
                return "message";
            }
            if (shipping_product_id.equals("없는 상품코드") || location_id.equals("없는 로케이션")) {
                model.addAttribute("message", "존재하지 않은 상품코드나 로케이션에 대해서는 저장처리할 수 없습니다!!");
                model.addAttribute("searchUrl", "/");
                return "message";
            }

            //최종 저장
            System.out.println("shipping_product_id = " + shipping_product_id);
            System.out.println("quantity = " + quantity);
            System.out.println("location_id = " + location_id);

            Map<String, String> map = new HashMap<String, String>();
            map.put("shipping_product_id", shipping_product_id);
            map.put("quantity", quantity);
            map.put("location_id", location_id);

            int pscnt = stockService.selectProductStock(map);
            int skuLimitCnt = 0;
            int orgSkuCnt = 0;
            int skuLimitCntMin = 0;
            //sku 처리
            if (pscnt > 0) {
                result = stockService.save(map);
            } else {
                skuLimitCnt = stockService.selectSkuLimitCnt(map);
                if (skuLimitCnt == 0) {
                    result = stockService.save(map);
                } else {
                    orgSkuCnt = stockService.selectorgSkuCnt(map);
                    if (skuLimitCnt > 1) {
                        skuLimitCntMin = skuLimitCnt - 1;
                        if (skuLimitCntMin >= orgSkuCnt) {
                            result = stockService.save(map);
                        } else {
                            errMsg = "해당 로케이션에는 더이상 새로운 상품을 넣을 수 없습니다.";
                            result = 0;
                        }
                    } else {
                        if (orgSkuCnt == 1) {
                            errMsg = "해당 로케이션에는 더이상 새로운 상품을 넣을 수 없습니다.";
                            result = 0;
                        } else {
                            result = stockService.save(map);
                        }
                    }
                }
            }


        }catch (Exception ex){

            model.addAttribute("message", ex.getMessage());
            model.addAttribute("searchUrl", "index");
            return "message";
        }

        if (result < 1) {
            model.addAttribute("message", errMsg);
            model.addAttribute("searchUrl", "/");
            return "message";
        } else {
            model.addAttribute("message", "저장에 성공하였습니다!!");
            model.addAttribute("searchUrl", "list");
            return "message";
        }
    }

}
