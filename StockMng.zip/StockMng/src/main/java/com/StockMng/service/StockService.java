package com.StockMng.service;

import com.StockMng.dto.StockDTO;
import com.StockMng.mapper.StockMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionTemplate;

import java.util.List;
import java.util.Map;

@Service
public class StockService {
    @Autowired
    StockMapper stockMapper;
    @Autowired
    TransactionTemplate transactionTemplate;

    @Transactional
    public List<StockDTO> selectList(){
        return stockMapper.StockList();
    }

    @Transactional
    public String selectShippingProductId(String productCode){
        return stockMapper.selectShippingProductId(productCode);
    }

    @Transactional
    public int selectShippingProductIdCnt(String productCode){
        return stockMapper.selectShippingProductIdCnt(productCode);
    }

    @Transactional
    public int selectLocationIdchk(String locationName) {
        return stockMapper.selectLocationIdchk(locationName);
    }

    @Transactional
    public String selectlocationId(String locationName) {
        return stockMapper.selectlocationId(locationName);
    }

    @Transactional
    public int save(Map<String, String> map) {
        return stockMapper.saveStock(map);
    }


    @Transactional
    public String selectsuggestionlocationCode(String productId) {
        return stockMapper.selectsuggestionlocationCode(productId);
    }

    @Transactional
    public int selectProductStock(Map<String, String> map) {
        return stockMapper.selectProductStock(map);
    }

    @Transactional
    public int selectSkuLimitCnt(Map<String, String> map) {
        return stockMapper.selectSkuLimitCnt(map);
    }

    @Transactional
    public int selectorgSkuCnt(Map<String, String> map) {
        return stockMapper.selectorgSkuCnt(map);
    }
}
