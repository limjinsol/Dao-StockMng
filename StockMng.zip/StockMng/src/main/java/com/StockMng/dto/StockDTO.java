package com.StockMng.dto;

import lombok.*;

import java.time.LocalDate;

@Getter
@Setter
@Data
public class StockDTO {
    private Integer stock_id;
    private Integer shipping_product_id;
    private Integer location_id;
    private Integer quantity;
    private LocalDate create_date;
    private String product_code;
    private String location_name;
}