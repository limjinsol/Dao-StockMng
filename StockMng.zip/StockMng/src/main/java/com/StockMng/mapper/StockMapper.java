package com.StockMng.mapper;

import com.StockMng.dto.StockDTO;
import org.apache.ibatis.annotations.Mapper;
import org.mybatis.spring.annotation.MapperScan;

import java.util.List;
import java.util.Map;

@Mapper
@MapperScan
public interface StockMapper {
    List<StockDTO> StockList();

    int saveStock(Map<String, String> map);

    String selectShippingProductId(String productCode);

    int selectShippingProductIdCnt(String productCode);

    int selectLocationIdchk(String locationName);

    String selectlocationId(String locationName);

    String selectsuggestionlocationCode(String productId);

    int selectProductStock(Map<String, String> map);

    int selectSkuLimitCnt(Map<String, String> map);

    int selectorgSkuCnt(Map<String, String> map);
}
