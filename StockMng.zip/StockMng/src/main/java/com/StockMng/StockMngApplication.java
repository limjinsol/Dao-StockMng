package com.StockMng;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StockMngApplication {

	public static void main(String[] args) {
		SpringApplication.run(StockMngApplication.class, args);
	}

}
